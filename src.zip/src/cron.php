<?php
require_once 'functions.php';
// This script should send XKCD updates to all registered emails.
// You need to implement this functionality.
